cd C:/Users/pashovt/Desktop/
img = imread("1k8s72xjqqq21.png");
image(img(:,:,:)) % whole image

image_matrix = zeros(size(img,1)*size(img,2), size(img,3));
% doesn't work
%image_matrix(1:size(img,2), 1) = img(200,:,1);
%image_matrix(1:size(img,2), 2) = img(200,:,2);
%image_matrix(1:size(img,2), 3) = img(200,:,3);


image(img(:,:,1)) % know to have a thermal reading

redColor = img(:,:,1);
greenColor = img(:,:,2);
blueColor = img(:,:,3);

figure; image(redColor)
figure; image(greenColor)
figure; image(blueColor)

bluesection = blueColor(1:50, 1:50);
bluesection(bluesection >= 160-160*0.6) = 0; % leaves only the different pigment pixel
% there is a high probability that this method in accurate
figure; image(bluesection)


fullbluesection = blueColor;
fullbluesection(fullbluesection >= 160-160*0.6) = 0; % reduction of the whole blue matrix
figure; image(fullbluesection)

% NOTE! THE METHOD IS HIGHLY ACCURATE FOR A CERTAIN THERMAL IMAGE
% there will be a need for the development of a method that does the
% analysis for anytime of thermal imaging picture.
%
% The current reduction method is a great way for removing data that isn't
% of interest.
% Applicable for Blue spectrum of the color


